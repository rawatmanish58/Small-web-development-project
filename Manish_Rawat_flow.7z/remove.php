<?php 
$details = $_POST['postdetails'];

$servername = "localhost";
$username = "root";
$password = "22357337man";
$dbname = "flow";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sqlD = "DELETE FROM details WHERE details = '$details'";

if ($conn->query($sqlD) === TRUE) {
    echo "1";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>