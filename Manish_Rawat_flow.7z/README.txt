Database created: only one with name 'flow'
Tables created in database: 
1. 'details'
   columnns: ID(auto increment) and details.

2. 'ongoing'
   columnns: ID(auto increment) and ongoingD.

3. 'hired'
   columnns: ID(auto increment) and details.

-------------------------------------------------------
Languages used:
Frontend: HTML, CSS, Javascript, Jquery, Semantic UI.
Backend: PHP, mySQL.

-------------------------------------------------------
Files created and their usage:

1. send.html:

This is the HTML file created to send the offer request to the new offers page of the specified professional. It contains an input box where the user will type the specified details of the offer.


2. register.php:

This is the PHP file where the detail is received provided in the send.html.
It sends the details to the 'details' table of 'flow' database.

3. account.php:
 MAIN FILE WITH THE THREE LAYOUTS
This is hybrid file where HTML and PHP are both embedded together. This is the page where the THREE LAYOUTS namely NEW OFFERS, ONGOING PROJECTS, and HIRED details are shown. It makes the AJAX call to remove.php, ongoing.php and flow.php files in order to process the data according to the requirement.

4. remove.php:

This is the PHP file which is called by account.php whenever the professional rejects the offer shown in the New Offers tab. The account.php makes an AJAX call to remove.php sending the required information to be removed from the 'details' table of 'flow' database. Then remove.php deletes the given information form the 'details' column of the 'flow' database.

5. flow.php:

This PHP file is called by account.php (again AJAX call) file whenever the professional accepts the offer. The details of the offer are then stored in the table 'ongoing' of the database 'flow' and are removed from the table 'details'. After successful transfer of details, the account.php reloads the data from the database and update the data of respective tabs(i.e., New offers, ongoing and hired).


6. ongoing.php:

This PHP file is called by account.php (again AJAX call) file whenever the professional complete the task provided in the Ongoing tab. The details of the offer are then stored in the table 'hired' of the database 'flow' and are removed from the table 'ongoing'. After successful transfer of details, the account.php reloads the data from the database and update the data of respective tabs(i.e., New offers, ongoing and hired).
