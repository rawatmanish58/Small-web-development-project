<?php 
$details = $_POST['postdetails'];

$servername = "localhost";
$username = "root";
$password = "22357337man";
$dbname = "flow";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO hired (details)
		VALUES ('$details')";

if ($conn->query($sql) === TRUE) {
    //echo $details;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
} 

// sql to delete a record
$sqlD = "DELETE FROM ongoing WHERE ongoingD = '$details'";

if ($conn->query($sqlD) === TRUE) {
    echo "1";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>