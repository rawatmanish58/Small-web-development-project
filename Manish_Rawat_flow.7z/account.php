<?php

$servername = "localhost";
$username = "root";
$password = "22357337man";
$dbname = "flow";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT details FROM details";
$records = $conn->query($sql);

$sql2 = "SELECT ongoingD FROM ongoing";
$records2 = $conn->query($sql2);


$sql3 = "SELECT details FROM hired";
$records3 = $conn->query($sql3);



$conn->close();
?>




<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href = "https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.2/semantic.min.css">
    <link rel="stylesheet" type="text/css" href = "https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.10/components/form.css">
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.10/semantic.min.js"> </script>
    <script src = "https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.10/components/form.js"> </script>
   <script type="text/javascript">
  $(document).ready(function(){
  $('.tabular.menu .item').tab();
  $('#main').click();
  });
 
 function move(e){
	var x = document.getElementById(e).innerHTML;
	$.post('flow.php',{postdetails:x},function(data){
		if(data == 1) {
			alert("Data successfully transferred");
			location.reload();
		}
		else alert('ERROR MOVING DATA');
	});
	
} 

  function remve(e){
	var r = confirm("Are you sure you want to REJECT the offer? (click OK to reject or Cancel to go back)");
	if(r == true){
	var x = document.getElementById(e).innerHTML;
	$.post('remove.php',{postdetails:x},function(data){
		if(data == 1) {
			location.reload();
			alert("Data successfully removed");
			
		}
		else alert('ERROR MOVING DATA');
	});
	}
	
} 
  function move2(e){
	var x = document.getElementById("ongoing" + e).innerHTML;
	 $.post('ongoing.php',{postdetails:x},function(data){
		if(data == 1) {
			alert("Data successfully transferred");
			location.reload();
		}
		else alert('ERROR MOVING DATA');
	}); 
	
}
</script>
  
  </head>
  
  
  <body>
 
			<!-- Menu -->
<div class="ui tabular menu">
  <div class="item" id="main" data-tab="tab-name">New Offers</div>
  <div class="item" data-tab="tab-name2">Ongoing Projects</div>
  <div class="item" data-tab="tab-name3">Hired</div>
</div>

			<!-- Content -->
<div class="ui tab" data-tab="tab-name">
	<div class="ui grid container">	  
	<?php 
	  if ($records->num_rows > 0) {
    // output data of each row
	  $x = 0;
      while($det = $records->fetch_assoc()) {
		  
		  echo '<div class="sixteen wide column "><p id="'.$x.'" style="font-weight:bold;font-size:20px">';
		  echo  $det['details'];
		  echo '</p><button class="positive ui button mini" onclick="move('.$x.')">Accept</button> <button class="negative ui button mini" onclick="remve('.$x.')">Reject</button><hr></div>';
		  $x++;
	  }
	  }
	   else {
			echo "0 offer requests";
		}
	  
	  ?>
    </div>


</div>
<div class="ui tab" data-tab="tab-name2">
<div class="ui grid container" id="ongoing">
	  <?php 
	  if ($records2->num_rows > 0) {
    // output data of each row
	  $x = 0;
      while($det = $records2->fetch_assoc()) {
		  
		  echo '<div class="sixteen wide column "><p id="ongoing'.$x.'"style="font-weight:bold;font-size:20px">';
		  echo  $det['ongoingD'];
		  echo '</p><button class="positive ui button mini" onclick="move2('.$x.')">Completed</button><hr></div>';
		  $x++;
	  }
	  }
	   else {
			echo "0 Projects Ongoing";
		}
	  
	  ?>
	  
    </div>
</div>
<div class="ui tab" data-tab="tab-name3">
<div class="ui grid container" id="hired">
	  <?php 
	  if ($records3->num_rows > 0) {
    // output data of each row
	  $x = 0;
      while($det = $records3->fetch_assoc()) {
		  
		  echo '<div class="sixteen wide column "><p style="font-weight:bold;font-size:20px">';
		  echo  $det['details'];
		  echo '</p><hr></div>';
		  $x++;
	  }
	  }
	   else {
			echo "0 projects hired";
		}
	  
	  ?>
    </div>
</div>

				<!-- PAGINATION 
<div class="ui pagination menu" style="position:fixed; top:95%">
  <a class="item">
    1
  </a>
  <div class="disabled item">
    ...
  </div>
  <a class="item active">
    10
  </a>
  <a class="item">
    11
  </a>
  <a class="item">
    12
  </a>
</div>-->


</body>
</html>